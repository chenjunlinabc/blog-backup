---
title: "Nuxt.js学习笔记"
categories: [ "学习" ]
tags: [ "vuejs","Nuxt.js" ]
draft: false
slug: "152"
date: "2022-06-05 21:36:00"
---

nuxt是一个基于vue的应用框架，用于创建服务端渲染应用，使用vite作为打包器，使用webpack作为构建工具


创建项目

yarn create nuxt-app nuxtTest

需要做一些选择，例如：选择TypeScript，选择Yarn，选择UI框架等等

安装依赖

yarn

启动项目

yarn dev

构建打包

yarn build


yarn start

启动测试环境
yarn test
       
