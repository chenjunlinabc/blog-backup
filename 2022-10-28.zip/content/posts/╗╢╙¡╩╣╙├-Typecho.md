---
title: "欢迎使用 Typecho"
categories: [ "默认" ]
tags: [  ]
draft: false
slug: "1"
date: "2021-03-17 00:00:00"
---

如果您看到这篇文章,表示您的 blog 已经安装成功.