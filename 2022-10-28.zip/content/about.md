---
title: "关于"
date: 2022-04-17T22:50:06+08:00
---





关于本站

这是本人的个人博客，分享一些本人学习过程中写的笔记


如果文章出现错误或者不正确的地方，欢迎在文章下提出，进行纠正，笔记会根据学习进度来进行更新或者修改

本站未注明转载的文章均为原创，转载请标明来源

本站是主站（cjlio.com）备份站点



---


免责声明

本站内容仅供学习和参阅使用，本网站内容仅代表作者本人的观点，内容仅供阅读，如有任何问题，欢迎随时留言或者联系站长（QQ：3066887865，email：a@cjlio.com），将会在第一时间为您做相关处理



---

自述：

2002年出生，星座：摩羯座

偏好语言：JavaScript(TypeScript)，Golang，Python

APP&小程序：Flutter，Taro

家里蹲公司的一名干饭攻城狮

最喜欢的游戏：CSGO，塞尔达传说：旷野之息

看完的小说：全职法师，雪鹰领主，吞噬星空，星辰变，牧龙师

目前在看小说：完美世界


---

联系方式：

邮箱：a#cjlio.com （#是啥不用多说了吧？@）

QQ：3066887865（请勿骚扰）

QQ群：61141438

wakatime统计：https://wakatime.com/@chenjunlinabc

GitHub：https://github.com/chenjunlinabc

Gitee：https://gitee.com/chenjunlinabc

Twitter：https://twitter.com/chenjunlina

B站: https://space.bilibili.com/373156565

steam：https://steamcommunity.com/profiles/76561198966883228/

备用站点：https://blog.cjlio.com


---


设备：

主力机：ThinkBook 14p Gen 2

    配置详情：
    
        CPU：AMD Ryzen 5 5600H
    
        内存：16G DDR4 3200MHz（双通道，板载）
    
        显卡：AMD Radeon(TM) Graphics（2GB）
    
        硬盘：西部数据 SN770黑盘 1TB
    
        网卡：Intel(R) Wi-Fi 6 AX200 160MHz
    
        操作系统：Windows 11专业工作站版


键盘：ikbc C87(茶轴) /  MSI GK50Z PLXEL 60度灰（红轴）

鼠标： 雷蛇 蝰蛇标准版 白色 6400DPI 

手机： Redmi k40 游戏增强版（12+258）

其他：Raspberry pi 3（树莓派）

耳机：Sony WF-1000XM3

代码编辑器：Visual Studio Code

浏览器：Microsoft Edge



---

书籍：

GO语言学习笔记，数学之美，深入浅出Docker，GO语言核心编程，JavaScript高级程序设计，深入浅出Nodejs，React进阶之路，Redis实战，深入浅出React和Redux，深入理解TypeScript，前端技术架构与工程，labuladong的算法小抄，算法图解，Python3网络爬虫开发实战，前端架构：从入门到微前端，前端开发核心知识进阶：从夯实基础到突破瓶颈，Vue.js设计与实现，MongoDB进阶与实战:微服务整合、性能优化、架构管理，Angular开发入门与实战
